<!-- start select modal -->
<div class="modal fade"  id="select-modal" tabindex="-1" role="dialog" aria-labelledby="select-modal_lbl"  data-backdrop="static" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h4 id="select-modal-lbl">Member Training</h4>
            </div>

            <div class="modal-body">
                <p style="font-size: 16px;">We notice that you are an LSV Lifesaving club member. Do you want to proceed to the public course training area, or do you wish to go into the volunteer member training area to register or complete training through the Volunteer training team.</p>
                <button class="btn btn-glow" class="close" data-dismiss="modal" aria-hidden="true">Public Training Area</button> <a class="btn btn-glow" href="http://mt.lsv-from-anywhere.com.au">Volunteer Member Training Area</a> 	            </div>
        </div>
    </div>
</div>
<!-- end select modal -->