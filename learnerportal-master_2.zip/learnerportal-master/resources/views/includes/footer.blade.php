<div class="footer">
    <p>Life Saving Victoria is a Registered Training Organisation # 21799 ABN: 21 102 927 364 <a href="http://www.lsv.com.au" target="_blank">www.lsv.com.au</a></p>
</div>