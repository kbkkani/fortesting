<p>Organisation name: {{ $organisation }}</p>
<p>Contact Name: {{ $contact_name }}</p>
<p>Contact Email: {{ $contact_email }}</p>
<p>Contact Number: {{ $contact_number }}</p>
<p>Courses: {{ $courses }}</p>
<p>Course Venue: {{ $venue }}</p>
<p>Date: {{ $date }}</p>
<p>Additional comments: {{ $comments }}</p>