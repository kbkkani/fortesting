<?php

return [
    'AXL_API_Token' => 'D4E9A85F-C343-43A4-9586409C185B6ADF',
    'AXL_WS_Token' => '731D225A-2150-46FF-B7592205B2B79574',
    'LMS-APIKEY'  => '2c3d0c2486f6c0115dfb75083e57fb6f',
    'AXL_API_URL' => 'https://admin.axcelerate.com.au/api/',
    'ERROR_LOG_FILE' => 'error_log/error_log.log'
];