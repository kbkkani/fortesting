<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Courseinfo extends Model
{
    protected $table = 'courseinfo';
    public $timestamps = false;
}
