<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CodeLog extends Model
{
    protected $table = 'code_log';
}
